Make sure the YeastGenes folder is in the same directory as the script
Then run the script

Should output a text file with the average percentage of GC content for each gene